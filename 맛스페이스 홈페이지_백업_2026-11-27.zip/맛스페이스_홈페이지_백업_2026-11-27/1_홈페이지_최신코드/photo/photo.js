/* 아바타 포토부스 — 사진을 아바타 얼굴 프레임(동그라미)에 넣고 저장. 모든 처리는 브라우저 안에서만, 서버 전송 없음. */
(function () {
  const $ = s => document.querySelector(s);
  const lang = () => (window.MATSPACE_LANG ? window.MATSPACE_LANG() : "ko");
  const tr = (ko, en) => (lang() === "en" ? en : ko);
  const canvas = $("#stage"), ctx = canvas.getContext("2d"), grab = $("#grab");
  const temp = document.createElement("canvas");
  const video = document.createElement("video"); video.setAttribute("playsinline", ""); video.muted = true;
  const AV = window.PHOTO_AVATARS;
  const q0 = new URLSearchParams(location.search).get("ilju");
  const S = { key: AV[q0] ? q0 : Object.keys(AV)[0], avatar: null, base: [.5, .5, .15], face: { cx: .5, cy: .5, r: .15, ry: .15 },
    photo: null, live: false, stream: null, facing: "user", mirror: false, zoom: 1, rot: 0, ox: 0, oy: 0, mode: "photo", hintKey: null };

  const HINTS = {
    pick: ["얼굴 사진을 넣고 싶다면 ‘사진 넣기’를 눌러 주세요. 스티커로만 꾸며도 좋아요.", "Tap “Add a photo” to put a face in. Or just decorate with stickers."],
    adjust: ["사진을 드래그해서 얼굴을 맞추고, 두 손가락으로 크기·기울기를 조절하세요. (슬라이더도 가능)", "Drag to fit the face. Pinch to resize and twist to rotate (sliders work too)."],
    live: ["얼굴을 프레임 안에 맞춘 뒤 ‘촬영하기’를 눌러 주세요.", "Fit the face inside the frame, then tap “Take photo”."],
    frame: ["프레임 안쪽을 끌면 위치가, 테두리의 동그란 점을 끌면 가로·세로 모양이 바뀌어요. 눈만 넣고 싶을 때도 좋아요.", "Drag inside to move the frame; drag the dots on its edge to change width and height."],
    nocam: ["카메라를 쓸 수 없어요. ‘앨범에서 고르기’로 사진을 선택해 주세요.", "Camera isn’t available. Please use “Choose from album”."],
    needPhoto: ["먼저 사진을 찍거나 골라 주세요.", "Please take or choose a photo first."]
  };
  const setHint = k => { S.hintKey = k; $("#hint").textContent = tr(...HINTS[k]); };

  function loadAvatar(k) {
    S.key = k; const info = AV[k], im = new Image();
    im.onload = () => {
      S.avatar = im; S.base = info.face.slice(); S.face = { cx: info.face[0], cy: info.face[1], r: info.face[2], ry: info.face[2] };
      $("#frameW").value = 1; $("#frameWVal").textContent = "100%"; $("#frameH").value = 1; $("#frameHVal").textContent = "100%";
      canvas.width = 720; canvas.height = Math.round(720 * im.naturalHeight / im.naturalWidth);
      S.front = null; draw();
      if (info.front) { const fr = new Image(); fr.onload = () => { if (S.key === k) { S.front = fr; draw(); } }; fr.src = info.front; }
    };
    im.src = info.src;
  }

  const sizeOf = s => [s.videoWidth || s.naturalWidth || s.width, s.videoHeight || s.naturalHeight || s.height];
  const hasSlot = () => S.live || !!S.photo;
  // 사진이 덮어야 하는 타원(회전 고려)의 가로·세로 반폭(W 기준)
  function ext(f) { const a = S.rot * Math.PI / 180, c = Math.cos(a), s = Math.sin(a); return [Math.sqrt(f.r * f.r * c * c + f.ry * f.ry * s * s), Math.sqrt(f.r * f.r * s * s + f.ry * f.ry * c * c)]; }
  function clampPan(W, f) {
    const src = S.live ? video : S.photo; if (!src) return; const [sw, sh] = sizeOf(src); if (!sw) return;
    const [ex, ey] = ext(f), k = Math.max(2 * ex * W / sw, 2 * ey * W / sh) * S.zoom;
    const mx = Math.max(0, sw * k / 2 / W - ex), my = Math.max(0, sh * k / 2 / W - ey);
    const a = S.rot * Math.PI / 180, ca = Math.cos(a), sa = Math.sin(a);
    let lx = S.ox * ca + S.oy * sa, ly = -S.ox * sa + S.oy * ca;
    lx = Math.min(mx, Math.max(-mx, lx)); ly = Math.min(my, Math.max(-my, ly));
    S.ox = lx * ca - ly * sa; S.oy = lx * sa + ly * ca;
  }
  function render(c, W, H, editor, noPhoto) {
    c.fillStyle = "#fff"; c.fillRect(0, 0, W, H);
    if (S.avatar) c.drawImage(S.avatar, 0, 0, W, H);
    const f = S.face, cx = f.cx * W, cy = f.cy * H, rx = f.r * W, ry = f.ry * W;
    const src = (noPhoto || !hasSlot()) ? null : (S.live ? video : S.photo), [sw, sh] = src ? sizeOf(src) : [0, 0];
    if (src && sw) {
      clampPan(W, f);
      if (temp.width !== W || temp.height !== H) { temp.width = W; temp.height = H; }
      const t = temp.getContext("2d"); t.setTransform(1, 0, 0, 1, 0, 0); t.globalCompositeOperation = "source-over"; t.clearRect(0, 0, W, H);
      const [ex, ey] = ext(f), k = Math.max(2 * ex * W / sw, 2 * ey * W / sh) * S.zoom, dw = sw * k, dh = sh * k;
      t.save(); t.translate(cx + S.ox * W, cy + S.oy * W); t.rotate(S.rot * Math.PI / 180); if (S.mirror) t.scale(-1, 1); t.drawImage(src, -dw / 2, -dh / 2, dw, dh); t.restore();
      t.globalCompositeOperation = "destination-in";
      t.save(); t.translate(cx, cy); t.scale(rx, ry);
      const g = t.createRadialGradient(0, 0, .93, 0, 0, 1); g.addColorStop(0, "rgba(0,0,0,1)"); g.addColorStop(1, "rgba(0,0,0,0)");
      t.fillStyle = g; t.fillRect(-100, -100, 200, 200); t.restore(); t.globalCompositeOperation = "source-over";
      c.drawImage(temp, 0, 0);
      c.beginPath(); c.ellipse(cx, cy, rx * .985, ry * .985, 0, 0, Math.PI * 2); c.strokeStyle = "rgba(80,60,45,.28)"; c.lineWidth = Math.max(1.5, Math.min(rx, ry) * .025); c.stroke();
    }
    if (S.front) c.drawImage(S.front, 0, 0, W, H);   // 앞에 있는 물체(나무 기둥 등)는 사진 위로 다시 덮기
    drawStickers(c, W, H);
    if (editor && hasSlot() && S.mode === "frame") {
      const m = Math.min(rx, ry);
      c.beginPath(); c.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); c.setLineDash([m * .14, m * .1]);
      c.lineWidth = Math.max(2.5, m * .05); c.strokeStyle = "#151515"; c.stroke(); c.lineWidth = Math.max(1, m * .02); c.strokeStyle = "#FFFF00"; c.stroke(); c.setLineDash([]);
    }
  }
  const fhLayer = $("#fhLayer"), FH = {};
  ["n", "e", "s", "w"].forEach(d => {
    const h = document.createElement("div"); h.className = "pb-fh pb-fh-" + d; fhLayer.appendChild(h); FH[d] = h; let last = null;
    h.addEventListener("pointerdown", e => { e.preventDefault(); e.stopPropagation(); h.setPointerCapture(e.pointerId); last = { x: e.clientX, y: e.clientY }; });
    h.addEventListener("pointermove", e => {
      if (!last) return; const k = 1 / canvas.getBoundingClientRect().width, dx = (e.clientX - last.x) * k, dy = (e.clientY - last.y) * k; last = { x: e.clientX, y: e.clientY };
      let rx = S.face.r, ry = S.face.ry; if (d === "e") rx += dx; if (d === "w") rx -= dx; if (d === "s") ry += dy; if (d === "n") ry -= dy;
      setFrameDims(rx, ry); if (!S.live) draw();
    });
    h.addEventListener("pointerup", () => { last = null; }); h.addEventListener("pointercancel", () => { last = null; });
  });
  function placeGrab() {
    const on = hasSlot(), k = canvas.clientWidth / canvas.width, f = S.face, rx = f.r * canvas.width * k, ry = f.ry * canvas.width * k;
    grab.style.display = on ? "" : "none";
    const L = canvas.offsetLeft + f.cx * canvas.width * k, T = canvas.offsetTop + f.cy * canvas.height * k;
    grab.style.left = (L - rx) + "px"; grab.style.top = (T - ry) + "px"; grab.style.width = (2 * rx) + "px"; grab.style.height = (2 * ry) + "px";
    fhLayer.style.display = on && S.mode === "frame" ? "" : "none";
    FH.n.style.left = FH.s.style.left = L + "px"; FH.n.style.top = (T - ry) + "px"; FH.s.style.top = (T + ry) + "px";
    FH.e.style.top = FH.w.style.top = T + "px"; FH.e.style.left = (L + rx) + "px"; FH.w.style.left = (L - rx) + "px";
  }
  const draw = () => { render(ctx, canvas.width, canvas.height, true); placeGrab(); placeStickers(); };
  window.addEventListener("resize", () => { placeGrab(); placeStickers(); });
  let raf = 0;
  function loop() { cancelAnimationFrame(raf); const step = () => { draw(); if (S.live) raf = requestAnimationFrame(step); }; step(); }
  function showButtons() { $("#btnsIdle").hidden = S.live || !!S.photo; $("#btnsLive").hidden = !S.live; $("#btnsDone").hidden = S.live || !S.photo; $("#stepFit").hidden = !hasSlot(); if (!hasSlot() && S.mode === "frame") setMode("photo"); renumber(); }
  function renumber() { let n = 0; document.querySelectorAll(".pb-step:not([hidden]) .pb-n").forEach(e => { e.textContent = ++n; }); }
  const resetZoom = () => { S.zoom = 1; S.rot = 0; S.ox = 0; S.oy = 0; $("#zoom").value = 1; $("#zoomVal").textContent = "100%"; $("#rot").value = 0; $("#rotVal").textContent = "0°"; };

  function stopCam() { if (S.stream) S.stream.getTracks().forEach(t => t.stop()); S.stream = null; S.live = false; video.srcObject = null; }
  async function startCam() {
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) { setHint("nocam"); $("#fileCam").click(); return; }
    stopCam();
    try {
      S.stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: S.facing, width: { ideal: 1280 }, height: { ideal: 1280 } }, audio: false });
      video.srcObject = S.stream; await video.play();
      S.live = true; S.photo = null; S.mirror = S.facing === "user"; resetZoom(); showButtons(); setHint("live"); loop();
    } catch (e) { stopCam(); showButtons(); setHint("nocam"); draw(); }
  }
  function shoot() {
    if (!S.live || !video.videoWidth) return;
    const c = document.createElement("canvas"); c.width = video.videoWidth; c.height = video.videoHeight; c.getContext("2d").drawImage(video, 0, 0);
    const m = S.mirror; stopCam(); S.photo = c; S.mirror = m; showButtons(); setHint("adjust"); draw();
  }
  async function useFile(file) {
    if (!file) return; stopCam(); let bmp = null;
    try { bmp = await createImageBitmap(file, { imageOrientation: "from-image" }); } catch (e) {}
    if (!bmp) bmp = await new Promise(res => { const im = new Image(); im.onload = () => res(im); im.onerror = () => res(null); im.src = URL.createObjectURL(file); });
    if (!bmp) return; S.photo = bmp; S.mirror = false; resetZoom(); showButtons(); setHint("adjust"); draw();
  }

  $("#btnCam").onclick = startCam;
  $("#btnFlip").onclick = () => { S.facing = S.facing === "user" ? "environment" : "user"; startCam(); };
  $("#btnOff").onclick = () => { stopCam(); showButtons(); setHint("pick"); draw(); };
  $("#btnShot").onclick = shoot;
  $("#btnFile").onclick = $("#btnFile2").onclick = () => $("#file").click();
  $("#btnRetake").onclick = () => { S.photo = null; showButtons(); startCam(); };
  $("#file").onchange = e => { useFile(e.target.files[0]); e.target.value = ""; };
  $("#fileCam").onchange = e => { useFile(e.target.files[0]); e.target.value = ""; };

  function setMode(m) {
    S.mode = m; $("#modePhoto").classList.toggle("on", m === "photo"); $("#modeFrame").classList.toggle("on", m === "frame");
    $("#rowZoom").hidden = m !== "photo"; $("#rowRot").hidden = m !== "photo"; $("#rowFrame").hidden = m !== "frame";
    setHint(m === "frame" ? "frame" : (S.photo ? "adjust" : S.live ? "live" : "pick")); draw();
  }
  $("#modePhoto").onclick = () => setMode("photo"); $("#modeFrame").onclick = () => setMode("frame");
  const setZoom = z => { S.zoom = Math.min(3, Math.max(1, z)); $("#zoom").value = S.zoom; $("#zoomVal").textContent = Math.round(S.zoom * 100) + "%"; };
  const setFrameDims = (rx, ry) => {
    rx = Math.min(.5, Math.max(.04, rx)); ry = Math.min(.5, Math.max(.04, ry)); S.face.r = rx; S.face.ry = ry;
    const w = rx / S.base[2], h = ry / S.base[2];
    $("#frameW").value = w; $("#frameWVal").textContent = Math.round(w * 100) + "%"; $("#frameH").value = h; $("#frameHVal").textContent = Math.round(h * 100) + "%";
  };
  const setRot = v => { v = Math.round(Math.max(-180, Math.min(180, v))); S.rot = v; $("#rot").value = v; $("#rotVal").textContent = v + "°"; };
  const normRot = v => { v = ((v + 180) % 360 + 360) % 360 - 180; return v; };
  $("#rot").oninput = e => { setRot(+e.target.value); draw(); };
  $("#rotL").onclick = () => { setRot(normRot(S.rot - 90)); draw(); };
  $("#rotR").onclick = () => { setRot(normRot(S.rot + 90)); draw(); };
  $("#rotReset").onclick = () => { setRot(0); draw(); };
  $("#zoom").oninput = e => { setZoom(+e.target.value); draw(); };
  $("#frameW").oninput = e => { setFrameDims(+e.target.value * S.base[2], S.face.ry); draw(); };
  $("#frameH").oninput = e => { setFrameDims(S.face.r, +e.target.value * S.base[2]); draw(); };
  $("#frameReset").onclick = () => { S.face = { cx: S.base[0], cy: S.base[1], r: S.base[2], ry: S.base[2] }; setFrameDims(S.base[2], S.base[2]); draw(); };

  const ptrs = new Map(); let p0 = null;
  const dist = () => { const [a, b] = [...ptrs.values()]; return Math.hypot(a.x - b.x, a.y - b.y); };
  const ang = () => { const [a, b] = [...ptrs.values()]; return Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI; };
  grab.addEventListener("pointerdown", e => { grab.setPointerCapture(e.pointerId); ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY }); if (ptrs.size === 2) p0 = { d: dist(), a: ang(), zoom: S.zoom, rot: S.rot, fr: S.face.r, fy: S.face.ry }; });
  grab.addEventListener("pointermove", e => {
    const p = ptrs.get(e.pointerId); if (!p) return;
    const k = canvas.width / canvas.getBoundingClientRect().width, dx = (e.clientX - p.x) * k, dy = (e.clientY - p.y) * k; p.x = e.clientX; p.y = e.clientY;
    if (ptrs.size === 2 && p0) { const s = dist() / p0.d; if (S.mode === "photo") { setZoom(p0.zoom * s); setRot(normRot(p0.rot + ang() - p0.a)); } else setFrameDims(p0.fr * s, p0.fy * s); }
    else if (ptrs.size === 1) { if (S.mode === "photo") { S.ox += dx / canvas.width; S.oy += dy / canvas.width; } else { S.face.cx += dx / canvas.width; S.face.cy += dy / canvas.height; } }
    if (!S.live) draw();
  });
  const up = e => { ptrs.delete(e.pointerId); if (ptrs.size < 2) p0 = null; };
  grab.addEventListener("pointerup", up); grab.addEventListener("pointercancel", up);
  grab.addEventListener("wheel", e => { e.preventDefault(); const f = e.deltaY < 0 ? 1.06 : .94; S.mode === "photo" ? setZoom(S.zoom * f) : setFrameDims(S.face.r * f, S.face.ry * f); if (!S.live) draw(); }, { passive: false });

  /* ---------- 스티커 ---------- */
  const ST = window.PHOTO_STICKERS, layer = $("#stkLayer");
  const EL_EN = { "목": "Wood", "화": "Fire", "토": "Earth", "금": "Metal", "수": "Water" };
  const ITEM_EN = { hairpin: "Hairpin", wand: "Princess wand", beanie: "Winter hat", crown: "Crown", ribbon: "Ribbon", glasses: "Star glasses" };
  const POS = [[.5, .12], [.3, .2], [.7, .2], [.4, .32], [.6, .08], [.22, .38], [.78, .36]];
  S.stk = []; S.sel = null; S.col = "목"; let sid = 0; const sprites = {};
  const sprite = s => { const k = s.k + "|" + s.el; if (!sprites[k]) { const im = new Image(); im.onload = () => draw(); im.src = ST.svgURL(s.k in ST.ART ? ST.ART[s.k](ST.EL[s.el]) : ST.ICONS[s.k]); sprites[k] = im; } return sprites[k]; };
  function drawStickers(c, W, H) {
    S.stk.forEach(s => { const im = sprite(s); if (!im.complete || !im.naturalWidth) return; const w = s.s * W;
      c.save(); c.translate(s.x * W, s.y * H); c.rotate(s.r * Math.PI / 180); c.scale(s.f ? -1 : 1, 1); c.drawImage(im, -w / 2, -w / 2, w, w); c.restore(); });
  }
  function syncStickers() {                       // 스티커 개수가 바뀔 때만 손잡이(드래그 영역) 다시 만듦
    const have = new Map([...layer.children].map(e => [+e.dataset.id, e]));
    have.forEach((e, id) => { if (!S.stk.some(s => s.id === id)) e.remove(); });
    S.stk.forEach(s => { if (have.has(s.id)) return; layer.appendChild(makeHandle(s)); });
    layer.querySelectorAll(".pb-sticker").forEach(e => e.classList.toggle("sel", S.sel && +e.dataset.id === S.sel.id));
    const s = S.sel; $("#stkCtl").hidden = !s; $("#stkClrWrap").hidden = !S.stk.length;
    if (s) { $("#stkSz").value = Math.round(s.s * 100); $("#stkSzV").textContent = Math.round(s.s * 100) + "%"; $("#stkRt").value = s.r; $("#stkRtV").textContent = s.r + "°"; }
  }
  function placeStickers() {
    const k = canvas.clientWidth / canvas.width;
    layer.style.left = canvas.offsetLeft + "px"; layer.style.top = canvas.offsetTop + "px"; layer.style.width = canvas.clientWidth + "px"; layer.style.height = canvas.clientHeight + "px";
    layer.querySelectorAll(".pb-sticker").forEach(e => {
      const s = S.stk.find(t => t.id === +e.dataset.id); if (!s) return; const w = s.s * canvas.width * k * .85;
      e.style.left = (s.x * canvas.width * k - w / 2) + "px"; e.style.top = (s.y * canvas.height * k - w / 2) + "px"; e.style.width = e.style.height = w + "px"; e.style.transform = "rotate(" + s.r + "deg)";
    });
  }
  function makeHandle(s) {
    const e = document.createElement("div"); e.className = "pb-sticker"; e.dataset.id = s.id; const pt = new Map(); let g = null;
    const two = () => { const [a, b] = [...pt.values()]; return { d: Math.hypot(a.x - b.x, a.y - b.y), a: Math.atan2(b.y - a.y, b.x - a.x) * 180 / Math.PI }; };
    e.addEventListener("pointerdown", ev => {
      ev.preventDefault(); ev.stopPropagation(); e.setPointerCapture(ev.pointerId); pt.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
      if (S.sel !== s) { S.sel = s; const i = S.stk.indexOf(s); S.stk.splice(i, 1); S.stk.push(s); syncStickers(); }
      if (pt.size === 2) { const t = two(); g = { d: t.d, a: t.a, s: s.s, r: s.r }; }
    });
    e.addEventListener("pointermove", ev => {
      const p = pt.get(ev.pointerId); if (!p) return; const rc = canvas.getBoundingClientRect(); const dx = ev.clientX - p.x, dy = ev.clientY - p.y; p.x = ev.clientX; p.y = ev.clientY;
      if (pt.size === 2 && g) { const t = two(); s.s = Math.min(.7, Math.max(.08, g.s * t.d / g.d)); s.r = Math.round(((g.r + t.a - g.a + 180) % 360 + 360) % 360 - 180); syncStickers(); }
      else if (pt.size === 1) { s.x = Math.min(1, Math.max(0, s.x + dx / rc.width)); s.y = Math.min(1, Math.max(0, s.y + dy / rc.height)); }
      if (!S.live) draw();
    });
    const up = ev => { pt.delete(ev.pointerId); if (pt.size < 2) g = null; };
    e.addEventListener("pointerup", up); e.addEventListener("pointercancel", up);
    e.addEventListener("wheel", ev => { ev.preventDefault(); s.s = Math.min(.7, Math.max(.08, s.s * (ev.deltaY < 0 ? 1.06 : .94))); syncStickers(); draw(); }, { passive: false });
    return e;
  }
  function addSticker(k) {
    if (S.stk.length >= 24) { toast(tr("스티커는 24개까지 붙일 수 있어요.", "You can add up to 24 stickers.")); return; }
    const isItem = k in ST.ART, n = S.stk.length % POS.length, s = { id: ++sid, k, el: isItem ? S.col : k, x: POS[n][0], y: POS[n][1], s: isItem ? .3 : .2, r: 0, f: false };
    S.stk.push(s); S.sel = s; syncStickers(); draw();
  }
  grab.addEventListener("pointerdown", () => { if (S.sel) { S.sel = null; syncStickers(); } });
  $("#stkSz").oninput = e => { if (S.sel) { S.sel.s = e.target.value / 100; syncStickers(); draw(); } };
  $("#stkRt").oninput = e => { if (S.sel) { S.sel.r = +e.target.value; syncStickers(); draw(); } };
  $("#stkDel").onclick = () => { if (S.sel) { S.stk.splice(S.stk.indexOf(S.sel), 1); S.sel = null; syncStickers(); draw(); } };
  $("#stkFlip").onclick = () => { if (S.sel) { S.sel.f = !S.sel.f; draw(); } };
  $("#stkDup").onclick = () => { if (S.sel) { const n = { ...S.sel, id: ++sid, x: Math.min(.95, S.sel.x + .06), y: Math.min(.95, S.sel.y + .05) }; S.stk.push(n); S.sel = n; syncStickers(); draw(); } };
  $("#stkClr").onclick = () => { S.stk = []; S.sel = null; syncStickers(); draw(); };
  function buildStickerPicker() {
    const en = lang() === "en", L = Object.keys(ST.EL);
    $("#stkCols").innerHTML = L.map(k => `<button class="pb-tab${k === S.col ? " on" : ""}" data-k="${k}"><span class="dot" style="background:${ST.EL[k].m}"></span>${en ? EL_EN[k] : k}</button>`).join("");
    $("#stkItems").innerHTML = ST.ITEMS.map(([k, n]) => `<button class="pb-stk" data-k="${k}"><img alt="" src="${ST.svgURL(ST.ART[k](ST.EL[S.col]))}">${en ? ITEM_EN[k] : n}</button>`).join("");
    $("#stkIcons").innerHTML = L.map(k => `<button class="pb-stk" data-k="${k}"><img alt="" src="${ST.svgURL(ST.ICONS[k])}">${en ? EL_EN[k] : k}</button>`).join("");
  }
  $("#stkCols").addEventListener("click", e => { const b = e.target.closest(".pb-tab"); if (!b) return; S.col = b.dataset.k; if (S.sel && S.sel.k in ST.ART) { S.sel.el = S.col; draw(); } buildStickerPicker(); });
  $("#stkItems").addEventListener("click", e => { const b = e.target.closest(".pb-stk"); if (b) addSticker(b.dataset.k); });
  $("#stkIcons").addEventListener("click", e => { const b = e.target.closest(".pb-stk"); if (b) addSticker(b.dataset.k); });
  buildStickerPicker();

  let url = null, blob = null, kind = "photo";
  const shareText = () => tr("내 사주 아바타로 사진 찍었어! 너도 해봐 🐾", "I made a photo with my Saju avatar! Try it too 🐾");
  const pageUrl = () => location.origin + "/photo/?ilju=" + encodeURIComponent(S.key) + (lang() === "en" ? "&lang=en" : "");
  function toast(msg) {
    const t = $("#toast"); t.textContent = msg; t.hidden = false; clearTimeout(toast.t); toast.t = setTimeout(() => { t.hidden = true; }, 2600);
  }
  function makeImage(withPhoto) {
    const aw = S.avatar.naturalWidth, ah = S.avatar.naturalHeight, k = Math.max(1, 1200 / Math.max(aw, ah));
    const W = Math.round(aw * k), H = Math.round(ah * k), out = document.createElement("canvas"); out.width = W; out.height = H;
    const o = out.getContext("2d"); o.imageSmoothingQuality = "high"; const m = S.mode; S.mode = "photo"; render(o, W, H, false, !withPhoto); S.mode = m;
    out.toBlob(b => {
      if (!b) return; blob = b; if (url) URL.revokeObjectURL(url); url = URL.createObjectURL(b); $("#resultImg").src = url; kind = S.photo ? "photo" : "art";
      $("#modalTitle").textContent = S.photo ? tr("완성! 아바타 사진이에요", "Your avatar photo is ready!") : tr("완성! 나만의 아바타예요", "Your avatar is ready!");
      $("#modal").hidden = false; document.body.classList.add("no-scroll");
    }, "image/png");
  }
  function save() {
    if (S.live) shoot();
    makeImage(true);
  }
  const fileName = () => "matspace-avatar-" + S.key + (kind === "art" ? "-illust" : "") + ".png";
  async function download() {
    if (!blob) return; const name = fileName(), file = new File([blob], name, { type: "image/png" });
    try { if (navigator.canShare && navigator.canShare({ files: [file] }) && /Android|iPhone|iPad|iPod/i.test(navigator.userAgent)) { await navigator.share({ files: [file], title: "Mat Space" }); return; } }
    catch (e) { if (e && e.name === "AbortError") return; }
    const a = document.createElement("a"); a.href = url; a.download = name; document.body.appendChild(a); a.click(); a.remove();
  }
  async function copyLink(u) {
    try { await navigator.clipboard.writeText(u); toast(tr("링크가 복사됐어요. 친구에게 붙여넣기 해주세요!", "Link copied. Paste it to your friend!")); }
    catch (e) { window.prompt(tr("링크를 복사해 친구에게 보내주세요", "Copy this link to share"), u); }
  }
  // 친구에게 공유: 결과 이미지가 있으면 이미지+링크, 없으면 링크만
  async function share(withImage) {
    const data = { title: tr("맛스페이스 사주 아바타 포토부스", "Mat Space Saju Avatar Photo Booth"), text: shareText(), url: pageUrl() };
    try {
      if (withImage && blob) {
        const file = new File([blob], fileName(), { type: "image/png" });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { await navigator.share({ ...data, files: [file] }); return; }
      }
      if (navigator.share) { await navigator.share(data); return; }
    } catch (e) { if (e && e.name === "AbortError") return; }
    copyLink(data.url);
  }
  const closeModal = () => { $("#modal").hidden = true; document.body.classList.remove("no-scroll"); };
  $("#btnSave").onclick = save; $("#btnRemove").onclick = () => { S.photo = null; resetZoom(); showButtons(); setHint("pick"); draw(); }; $("#btnShare").onclick = () => share(false); $("#btnShareImg").onclick = () => share(true); $("#btnDl").onclick = download; $("#btnClose").onclick = closeModal;
  $("#modal").addEventListener("click", e => { if (e.target.id === "modal") closeModal(); });

  /* ---------- 아바타 고르기 ---------- */
  const STEM_KO = { '갑':'갑목','을':'을목','병':'병화','정':'정화','무':'무토','기':'기토','경':'경금','신':'신금','임':'임수','계':'계수' };
  const STEM_EN = { '갑':'Yang Wood','을':'Yin Wood','병':'Yang Fire','정':'Yin Fire','무':'Yang Earth','기':'Yin Earth','경':'Yang Metal','신':'Yin Metal','임':'Yang Water','계':'Yin Water' };
  function stemLabel(s) { return (document.documentElement.lang === 'en' || /[?&]lang=en/.test(location.search)) ? STEM_EN[s] : STEM_KO[s]; }
  function buildPicker() {
    const cur = S.stemTab;
    $("#tabs").innerHTML = window.SAJU.STEMS.map(s => `<button class="pb-tab${s === cur ? " on" : ""}" data-s="${s}">${stemLabel(s)}</button>`).join("");
    const items = Object.keys(AV).filter(g => g[0] === cur).sort((a, b) => window.SAJU.BRANCHES.indexOf(a[1]) - window.SAJU.BRANCHES.indexOf(b[1]));
    $("#grid").innerHTML = items.map(g => `<button class="pb-av${g === S.key ? " on" : ""}" data-g="${g}"><img src="img/${g}.webp" alt="${window.I18N.avatarName(g, lang())}" loading="lazy"><b>${window.I18N.avatarName(g, lang())}</b></button>`).join("");
  }
  $("#tabs").addEventListener("click", e => { const b = e.target.closest(".pb-tab"); if (!b) return; S.stemTab = b.dataset.s; buildPicker(); });
  $("#grid").addEventListener("click", e => { const b = e.target.closest(".pb-av"); if (!b) return; loadAvatar(b.dataset.g); buildPicker(); });

  window.addEventListener("langchange", () => { buildPicker(); buildStickerPicker(); if (S.hintKey) $("#hint").textContent = tr(...HINTS[S.hintKey]); draw(); });
  window.addEventListener("pagehide", stopCam);
  S.stemTab = S.key[0]; buildPicker();
  loadAvatar(S.key); showButtons(); setHint("pick");
  renumber();
})();
