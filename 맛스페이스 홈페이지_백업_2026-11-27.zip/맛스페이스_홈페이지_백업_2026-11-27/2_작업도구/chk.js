const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();
const need=['맛스페이스 주식회사','김도희','260-88-03892','제2026-서울영등포-2451호','서울특별시 영등포구 선유서로21길 14 2층 201-640호','1588-3008 (고객번호 1493-4472)','matspaceglobal@gmail.com','Vercel Inc.','이용약관','개인정보처리방침'];
for(const js of [false,true]){
 const c=await b.newContext({javaScriptEnabled:js});
 for(const u of ['index.html','legal/terms/saju-diary/','karma/','service/saju-diary/']){
  const p=await c.newPage();await p.goto('http://localhost:8765/'+u+'?lang=ko');await p.waitForTimeout(500);
  const t=await p.$eval('footer.footer',e=>e.innerText);const n=await p.$$eval('footer.footer',a=>a.length);
  const hrefs=await p.$$eval('.footer-legal a',a=>a.map(x=>x.getAttribute('href')));
  console.log('JS',js,u,'footers',n,'missing',need.filter(x=>!t.includes(x)),hrefs.join(' '));await p.close()}
 await c.close()}
await b.close()})();
