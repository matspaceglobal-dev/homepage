const {chromium}=require('playwright');(async()=>{const b=await chromium.launch();const E=[];
for(const [u,n,w,full] of [['legal/terms/saju-diary/','a',1280,false],['legal/privacy/saju-diary/2026-08-14/','b',1280,false],['legal/privacy/','c',390,false]]){
const p=await b.newPage({viewport:{width:w,height:1000}});p.on('requestfailed',r=>E.push(u+' FAIL '+r.url()));p.on('response',r=>{if(r.status()>=400)E.push(u+' '+r.status()+' '+r.url())});
await p.goto('http://localhost:8765/'+u+'?lang=ko');await p.waitForTimeout(700);
console.log(u,await p.$$eval('.lg-tree a',a=>a.map(x=>x.getAttribute('href'))).then(x=>x.join(' ')));
await p.screenshot({path:`lg2_${n}.png`});await p.close()}
const p=await b.newPage({viewport:{width:1280,height:900}});await p.goto('http://localhost:8765/legal/privacy/saju-diary/?lang=ko');await p.waitForTimeout(600);
const t=await p.$('.lg-table');await t.scrollIntoViewIfNeeded();await p.screenshot({path:'lg2_tbl.png'});
console.log(await p.$eval('.lg-doc',e=>e.innerText.slice(-420)));
console.log(E);await b.close()})();
