const {chromium}=require('playwright');const fs=require('fs');const path=require('path');
const SITE=process.env.SITE;
const files=process.argv.slice(2);
(async()=>{const b=await chromium.launch();
for(const f of files){
  const rel=path.relative(SITE,f);const p=await b.newPage({viewport:{width:1280,height:900}});
  await p.goto('http://localhost:8766/'+rel+'?lang=ko');await p.waitForTimeout(600);
  let h=await p.$eval('footer.footer',e=>e.outerHTML);
  await p.close();
  h=h.replace(/ data-ko="[^"]*"/g,'');
  let s=fs.readFileSync(f,'utf8');
  const re=/<div id="site-footer">(<!--sf-->[\s\S]*?<\/footer>)?<\/div>/;
  if(!re.test(s)){console.log('NO MATCH',rel);continue}
  s=s.replace(re,()=>`<div id="site-footer"><!--sf-->${h}</div>`);
  fs.writeFileSync(f,s);console.log('ok',rel,h.length);
}
await b.close()})();
