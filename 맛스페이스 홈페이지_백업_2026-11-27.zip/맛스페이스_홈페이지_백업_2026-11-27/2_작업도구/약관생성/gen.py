import re,os,html
SITE='/mnt/user-data/outputs/matspace-homepage'
DOCS={
 'terms':{'ko':'이용약관','en':'Terms of Service','full':'사주일기 서비스 이용약관','desc':'맛스페이스 사주일기 서비스 이용약관'},
 'privacy':{'ko':'개인정보처리방침','en':'Privacy Policy','full':'사주일기 개인정보처리방침','desc':'맛스페이스 사주일기 개인정보처리방침'},
}
VERS=[ # newest first
 {'date':'2026-12-04','dot':'2026.12.04','note':'운영 주체 변경 (개인 → 맛스페이스 주식회사)','ko':'2026년 12월 4일'},
 {'date':'2026-08-14','dot':'2026.08.14','note':'제정 (운영자: 김도희)','ko':'2026년 8월 14일'},
]
def v2(src,key):
    s=src
    s=s.replace('시행일: 2026년 8월 14일 | 운영자: 김도희','시행일: 2026년 12월 4일 | 운영자: 맛스페이스 주식회사',1)
    s=s.replace('김도희(이하 "운영자")','맛스페이스 주식회사(이하 "운영자")')
    s=s.replace('공고일: 2026년 8월 14일\n시행일: 2026년 8월 14일\n운영자: 김도희 | matspaceglobal@gmail.com','공고일: 2026년 11월 27일\n시행일: 2026년 12월 4일\n운영자: 맛스페이스 주식회사 (대표이사 김도희) | matspaceglobal@gmail.com')
    s=s.replace('- 담당자: 김도희','- 담당자: 김도희 (대표이사)')
    s+='\n## 개정 이력\n- 2026년 12월 4일: 운영 주체 변경(개인 김도희 → 맛스페이스 주식회사). 그 외 내용 변경 없음\n- 2026년 8월 14일: 제정\n'
    return s
def esc(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'\*(.+?)\*',r'<em>\1</em>',t)
    return t
def render(md):
    L=md.strip('\n').split('\n');out=[];i=0;title='';meta=''
    def flush(kind):
        pass
    while i<len(L):
        ln=L[i].rstrip()
        if not ln: i+=1;continue
        if ln.startswith('# '): title=ln[2:];i+=1;continue
        if ln.startswith('시행일:') and not meta and i<3: meta=ln;i+=1;continue
        if ln.startswith('## '): out.append(f'<h2>{esc(ln[3:])}</h2>');i+=1;continue
        if ln.startswith('### '): out.append(f'<h3>{esc(ln[4:])}</h3>');i+=1;continue
        if ln.startswith('|'):
            rows=[]
            while i<len(L) and L[i].startswith('|'):
                rows.append([c.strip() for c in L[i].strip('|').split('|')]);i+=1
            h='<tr>'+''.join(f'<th>{esc(c)}</th>' for c in rows[0])+'</tr>'
            b=''.join('<tr>'+''.join(f'<td>{esc(c)}</td>' for c in r)+'</tr>' for r in rows[1:])
            out.append(f'<div class="lg-table"><table>{h}{b}</table></div>');continue
        if ln.startswith('- '):
            its=[]
            while i<len(L) and L[i].startswith('- '): its.append(L[i][2:]);i+=1
            out.append('<ul>'+''.join(f'<li>{esc(x)}</li>' for x in its)+'</ul>');continue
        if re.match(r'^\d+\. ',ln):
            its=[]
            while i<len(L) and re.match(r'^\d+\. ',L[i]): its.append(re.sub(r'^\d+\. ','',L[i]));i+=1
            out.append('<ol>'+''.join(f'<li>{esc(x)}</li>' for x in its)+'</ol>');continue
        if ln.startswith('*※'): out.append(f'<p class="note">{esc(ln)}</p>');i+=1;continue
        if ln[0] in '①②③④⑤':
            out.append(f'<p class="cl"><span>{ln[0]}</span>{esc(ln[1:].strip())}</p>');i+=1;continue
        if re.match(r'^(공고일|시행일|운영자):',ln):
            out.append(f'<p class="lg-sign">{esc(ln)}</p>');i+=1;continue
        out.append(f'<p>{esc(ln)}</p>');i+=1
    return title,meta,'\n'.join(out)
def tree(cur_key,cur_date,rel):
    parts=[]
    for k,d in DOCS.items():
        lis=''
        for n,v in enumerate(VERS):
            href=f"{rel}legal/{k}/" if n==0 else f"{rel}legal/{k}/{v['date']}/"
            c=' class="cur"' if (k==cur_key and v['date']==cur_date) else ''
            badge='<i>현행</i>' if n==0 else ''
            lis+=f'<li><a{c} href="{href}"><b>{v["dot"]} 시행</b>{badge}<small>{v["note"]}</small></a></li>'
        op=' open' if k==cur_key else ''
        parts.append(f'<details{op}><summary>{d["ko"]}</summary><ul>{lis}</ul></details>')
    return '<nav class="lg-tree" aria-label="문서 목록과 개정 이력"><p class="lg-tree-h">개정 이력</p>'+''.join(parts)+'</nav>'
def page(k,vi,body,title,meta,deep=False):
    v=VERS[vi];d=DOCS[k];cur=vi==0
    rel='../../../' if (deep or not cur) else '../../'
    path_cur=f'{rel}legal/{k}/'
    banner='' if cur else f'<div class="lg-old">이 문서는 <b>{v["dot"]}</b> 시행 <b>이전 버전</b>입니다. <a href="{path_cur}">현행 문서 보기 →</a></div>'
    return f'''<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{d["ko"]} | 맛스페이스 Mat Space</title>
  <meta name="description" content="{d["desc"]} ({v["dot"]} 시행)" />
  <meta name="theme-color" content="#151515" />
  <link rel="icon" href="{rel}favicon.svg" type="image/svg+xml" />
  <link rel="stylesheet" href="{rel}style.css" />
</head>
<body data-root="{rel}" data-page="legal" data-title-en="{d["en"]} | Mat Space">
  <div id="site-header"></div>
  <main>
    <section class="page-hero">
      <div class="blob blob-1" aria-hidden="true"></div>
      <div class="container">
        <p class="breadcrumb" data-en="Legal › <b>{d["en"]}</b>">약관 › <b>{d["ko"]}</b></p>
        <h1 data-en="{d["en"]}">{html.escape(title)}</h1>
        <p class="lg-meta">{html.escape(meta)}</p>
        <p class="lg-lang" data-en="The full text is provided in Korean.">본문은 한국어로 제공돼요.</p>
      </div>
    </section>
    <section class="section lg-section">
      <div class="container lg-grid">
        {tree(k,v["date"],rel)}
        <article class="lg-doc">
          {banner}
          {body}
        </article>
      </div>
    </section>
  </main>
  <div id="site-footer"></div>
  <script src="{rel}config.js"></script>
  <script src="{rel}layout.js"></script>
</body>
</html>
'''
for k in DOCS:
    v1=open(f'{k}_v1.md').read();v2s=v2(v1,k)
    for vi,src in enumerate([v2s,v1]):
        t,m,b=render(src)
        p=f'{SITE}/legal/{k}/'+('' if vi==0 else VERS[vi]['date']+'/')
        os.makedirs(p,exist_ok=True)
        open(p+'index.html','w').write(page(k,vi,b,t,m))
        if vi==0:
            q=f'{SITE}/legal/{k}/{VERS[0]["date"]}/';os.makedirs(q,exist_ok=True)
            open(q+'index.html','w').write(page(k,vi,b,t,m,True))
print('ok')
