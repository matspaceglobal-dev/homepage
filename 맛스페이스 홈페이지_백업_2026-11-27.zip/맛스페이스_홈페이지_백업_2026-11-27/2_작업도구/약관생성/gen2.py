import re,os,html
SITE='/mnt/user-data/outputs/matspace-homepage'
DOCS={
 'terms':{'ko':'이용약관','en':'Terms of Service','full':'사주일기 서비스 이용약관','desc':'맛스페이스 사주일기 서비스 이용약관'},
 'privacy':{'ko':'개인정보처리방침','en':'Privacy Policy','full':'사주일기 개인정보처리방침','desc':'맛스페이스 사주일기 개인정보처리방침'},
}
SERVICES=[ # 새 앱을 배포하면 여기에 한 블록을 추가하면 트리에 나타나요
 {'key':'saju-diary','ko':'사주일기','vers':[ # 최신순
   {'date':'2026-12-04','dot':'2026.12.04','note':'유료 서비스·결제, AI 예측 반영 / 운영 주체 변경 (개인 → 맛스페이스 주식회사)'},
   {'date':'2026-08-14','dot':'2026.08.14','note':'제정 (운영자: 김도희)'},
 ]},
]
SRC={('terms','saju-diary','2026-12-04'):'terms_12-04.md',('terms','saju-diary','2026-08-14'):'terms_v1.md',
     ('privacy','saju-diary','2026-12-04'):'privacy_12-04.md',('privacy','saju-diary','2026-08-14'):'privacy_v1.md'}
def corp(src):
    s=src
    s=s.replace('| 운영자: 김도희','| 운영자: 맛스페이스 주식회사',1)
    s=s.replace('김도희(이하 "운영자")','맛스페이스 주식회사(이하 "운영자")')
    s=s.replace('운영자: 김도희 | matspaceglobal@gmail.com','운영자: 맛스페이스 주식회사 (대표이사 김도희) | matspaceglobal@gmail.com')
    s=s.replace('- 담당자: 김도희','- 담당자: 김도희 (대표이사)')
    s+='\n## 개정 이력\n- 2026년 12월 4일: 유료 서비스·결제, AI 예측 기능 반영 및 운영 주체 변경(개인 김도희 → 맛스페이스 주식회사)\n- 2026년 8월 14일: 제정\n'
    return s
def esc(t):
    t=html.escape(t,quote=False)
    t=re.sub(r'\*(.+?)\*',r'<em>\1</em>',t)
    return t
def render(md):
    L=md.strip('\n').split('\n');out=[];i=0;title='';meta=''
    def flush(kind):
        pass
    while i<len(L):
        ln=L[i].rstrip()
        if not ln: i+=1;continue
        if ln.startswith('# '): title=ln[2:];i+=1;continue
        if ln.startswith('시행일:') and not meta and i<3: meta=ln;i+=1;continue
        if ln.startswith('## '): out.append(f'<h2>{esc(ln[3:])}</h2>');i+=1;continue
        if ln.startswith('### '): out.append(f'<h3>{esc(ln[4:])}</h3>');i+=1;continue
        if ln.startswith('|'):
            rows=[]
            while i<len(L) and L[i].startswith('|'):
                rows.append([c.strip() for c in L[i].strip('|').split('|')]);i+=1
            h='<tr>'+''.join(f'<th>{esc(c)}</th>' for c in rows[0])+'</tr>'
            b=''.join('<tr>'+''.join(f'<td>{esc(c)}</td>' for c in r)+'</tr>' for r in rows[1:])
            out.append(f'<div class="lg-table"><table>{h}{b}</table></div>');continue
        if ln.startswith('- '):
            its=[]
            while i<len(L) and L[i].startswith('- '): its.append(L[i][2:]);i+=1
            out.append('<ul>'+''.join(f'<li>{esc(x)}</li>' for x in its)+'</ul>');continue
        if re.match(r'^\d+\. ',ln):
            its=[]
            while i<len(L) and re.match(r'^\d+\. ',L[i]): its.append(re.sub(r'^\d+\. ','',L[i]));i+=1
            out.append('<ol>'+''.join(f'<li>{esc(x)}</li>' for x in its)+'</ol>');continue
        if ln.startswith('*※') or ln.startswith('※'): out.append(f'<p class="note">{esc(ln)}</p>');i+=1;continue
        if ln[0] in '①②③④⑤':
            out.append(f'<p class="cl"><span>{ln[0]}</span>{esc(ln[1:].strip())}</p>');i+=1;continue
        if re.match(r'^(공고일|시행일|운영자):',ln):
            out.append(f'<p class="lg-sign">{esc(ln)}</p>');i+=1;continue
        out.append(f'<p>{esc(ln)}</p>');i+=1
    return title,meta,'\n'.join(out)
def vpath(k,s,vi,v):
    return f"legal/{k}/{s['key']}/" + ('' if vi==0 else v['date']+'/')
def tree(cur_k,cur_s,cur_date,rel):
    parts=[]
    for k,d in DOCS.items():
        inner=''
        for s in SERVICES:
            lis=''
            for vi,v in enumerate(s['vers']):
                c=' class="cur"' if (k==cur_k and s['key']==cur_s and v['date']==cur_date) else ''
                badge='<i>현행</i>' if vi==0 else ''
                lis+=f'<li><a{c} href="{rel}{vpath(k,s,vi,v)}"><b>{v["dot"]} 시행</b>{badge}<small>{v["note"]}</small></a></li>'
            op=' open' if (k==cur_k and s['key']==cur_s) else ''
            inner+=f'<details class="lg-svc"{op}><summary>{s["ko"]}</summary><ul>{lis}</ul></details>'
        op=' open' if k==cur_k else ''
        parts.append(f'<details{op}><summary>{d["ko"]}</summary>{inner}</details>')
    return '<nav class="lg-tree" aria-label="문서 목록과 개정 이력"><p class="lg-tree-h">약관 · 개정 이력</p>'+''.join(parts)+'</nav>'
def page(k,s,vi,body,title,meta,depth):
    v=s['vers'][vi];d=DOCS[k];cur=vi==0
    rel='../'*depth
    cur_url=f"{rel}legal/{k}/{s['key']}/"
    banner='' if cur else f'<div class="lg-old">이 문서는 <b>{v["dot"]}</b> 시행 <b>이전 버전</b>입니다. <a href="{cur_url}">현행 문서 보기 →</a></div>'
    return f'''<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>{d["ko"]} · {s["ko"]} | 맛스페이스 Mat Space</title>
  <meta name="description" content="{s["ko"]} {d["ko"]} ({v["dot"]} 시행)" />
  <meta name="theme-color" content="#151515" />
  <link rel="icon" href="{rel}favicon.svg" type="image/svg+xml" />
  <link rel="stylesheet" href="{rel}style.css" />
</head>
<body data-root="{rel}" data-page="legal" data-title-en="{d["en"]} | Mat Space">
  <div id="site-header"></div>
  <main>
    <section class="page-hero">
      <div class="blob blob-1" aria-hidden="true"></div>
      <div class="container">
        <p class="breadcrumb" data-en="Legal › {d["en"]} › <b>Saju Diary</b>">약관 › {d["ko"]} › <b>{s["ko"]}</b></p>
        <h1 data-en="{d["en"]}">{html.escape(title)}</h1>
        <p class="lg-meta">{html.escape(meta)}</p>
        <p class="lg-lang" data-en="The full text is provided in Korean.">본문은 한국어로 제공돼요.</p>
      </div>
    </section>
    <section class="section lg-section">
      <div class="container lg-grid">
        {tree(k,s["key"],v["date"],rel)}
        <article class="lg-doc">
          {banner}
          {body}
        </article>
      </div>
    </section>
  </main>
  <div id="site-footer"></div>
  <script src="{rel}config.js"></script>
  <script src="{rel}layout.js"></script>
</body>
</html>
'''
import shutil
shutil.rmtree(SITE+'/legal',ignore_errors=True)
for k in DOCS:
    for s in SERVICES:
        for vi,v in enumerate(s['vers']):
            src=open(SRC[(k,s['key'],v['date'])]).read()
            if vi==0: src=corp(src)   # 현행 버전은 홈페이지 게시용(법인 명의)
            t,m,b=render(src)
            # 버전별 고유 주소 (과거 버전은 여기에만, 현행은 아래 '현행 주소'에도)
            p=f"{SITE}/legal/{k}/{s['key']}/{v['date']}/";os.makedirs(p,exist_ok=True)
            open(p+'index.html','w').write(page(k,s,vi,b,t,m,4))
            if vi==0:
                p=f"{SITE}/legal/{k}/{s['key']}/";open(p+'index.html','w').write(page(k,s,vi,b,t,m,3))
                if len(SERVICES)==1: # 서비스가 하나뿐인 동안은 /legal/terms/ 도 현행 문서를 바로 보여줘요
                    p=f"{SITE}/legal/{k}/";open(p+'index.html','w').write(page(k,s,vi,b,t,m,2))
print('ok')
